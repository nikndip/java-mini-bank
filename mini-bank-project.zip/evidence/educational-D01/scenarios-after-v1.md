# Повторные проверки D01 после первой попытки

Поднабор принятого scenarios-v2.md. Вводы и ожидания не изменены.

### T04 Нижние границы суммы и баланса, точное исчерпание средств

- Требования: R02, R05, R06, R07, R08, R10, R11, R12.
- Проверяемое условие: сумма 1 допустима; перевод всех средств оставляет баланс 0; последующий перевод с нулевого баланса отклоняется без изменения состояния.
- Тип: **граничный**. Точные границы: минимальная сумма — 1; минимальный баланс — 0; перевод 1 при балансе 1 успешен, при балансе 0 даёт `ERR_FUNDS`.
- Действие: запуск программы с указанным stdin.
- Ожидаемый код завершения: не нормируется R01–R12; фактический код сохраняется при запуске.
- Ожидаемый stderr: пустой.
- Статус выполнения: не проверено.

Вход stdin:

```text
deposit A 1
transfer A B 1
balance A
balance B
history
transfer A B 1
balance A
balance B
history
exit
```

Ожидаемый stdout:

```text
OK DEPOSIT A 1
OK TRANSFER A B 1
BALANCE A 0
BALANCE B 1
DEPOSIT A 1
TRANSFER A B 1
ERR_FUNDS
BALANCE A 0
BALANCE B 1
DEPOSIT A 1
TRANSFER A B 1
BYE
```


### T05 Максимальная сумма и максимальный баланс

- Требования: R02, R05, R06, R07, R08, R10, R11, R12.
- Проверяемое условие: сумма 1000000000 допустима для обеих финансовых операций; баланс может точно достигать лимита; пополнение сверх лимита не изменяет состояние.
- Тип: **граничный**. Точные границы: максимальная сумма и баланс — 1000000000; попытка увеличить такой баланс на 1 отклоняется.
- Действие: запуск программы с указанным stdin.
- Ожидаемый код завершения: не нормируется R01–R12; фактический код сохраняется при запуске.
- Ожидаемый stderr: пустой.
- Статус выполнения: не проверено.

Вход stdin:

```text
deposit A 1000000000
balance A
balance B
history
deposit A 1
balance A
balance B
history
transfer A B 1000000000
balance A
balance B
history
exit
```

Ожидаемый stdout:

```text
OK DEPOSIT A 1000000000
BALANCE A 1000000000
BALANCE B 0
DEPOSIT A 1000000000
ERR_LIMIT
BALANCE A 1000000000
BALANCE B 0
DEPOSIT A 1000000000
OK TRANSFER A B 1000000000
BALANCE A 0
BALANCE B 1000000000
DEPOSIT A 1000000000
TRANSFER A B 1000000000
BYE
```


### T07 Лимит получателя при достаточных средствах отправителя

- Требования: R02, R06, R07, R08, R10, R11, R12.
- Проверяемое условие: перевод отклоняется при превышении лимита получателя; перевод ровно до лимита успешен; каждый отказ сохраняет оба баланса и историю.
- Тип: **граничный**. При балансе B 999999995 перевод 6 дал бы 1000000001 и отклоняется; перевод 5 даёт ровно 1000000000. Следующий перевод 1 снова превышает лимит.
- Действие: запуск программы с указанным stdin.
- Ожидаемый код завершения: не нормируется R01–R12; фактический код сохраняется при запуске.
- Ожидаемый stderr: пустой.
- Статус выполнения: не проверено.

Вход stdin:

```text
deposit A 10
deposit B 999999995
balance A
balance B
history
transfer A B 6
balance A
balance B
history
transfer A B 5
balance A
balance B
history
transfer A B 1
balance A
balance B
history
exit
```

Ожидаемый stdout:

```text
OK DEPOSIT A 10
OK DEPOSIT B 999999995
BALANCE A 10
BALANCE B 999999995
DEPOSIT A 10
DEPOSIT B 999999995
ERR_LIMIT
BALANCE A 10
BALANCE B 999999995
DEPOSIT A 10
DEPOSIT B 999999995
OK TRANSFER A B 5
BALANCE A 5
BALANCE B 1000000000
DEPOSIT A 10
DEPOSIT B 999999995
TRANSFER A B 5
ERR_LIMIT
BALANCE A 5
BALANCE B 1000000000
DEPOSIT A 10
DEPOSIT B 999999995
TRANSFER A B 5
BYE
```


### T12 Неверные суммы и длинные начальные нули

- Требования: R02, R05, R06, R07, R08, R10, R11, R12.
- Проверяемое условие: длинная запись с начальными нулями и числовым значением 1 допустима для обеих операций. Отклоняются ноль, значение выше максимума, число за пределами `long`, знаки, дроби, экспоненты, цифры не из ASCII и другие символы. После отказов состояние сохраняется.
- Тип: **граничный и ошибочный ввод**. Недопустимые соседние значения суммы: 0 и 1000000001; допустимое значение с длинным префиксом нулей — 1.
- Действие: запуск программы с указанным stdin. Символы `١` и `１` передаются в UTF-8 как часть входа.
- Ожидаемый код завершения: не нормируется R01–R12; фактический код сохраняется при запуске.
- Ожидаемый stderr: пустой.
- Статус выполнения: не проверено.

Вход stdin:

```text
deposit A 25
deposit B 10
deposit A 0000000000000000000000000000000000000001
transfer B A 0000000000000000000000000000000000000001
balance A
balance B
history
deposit A 0
transfer A B 000
deposit A 1000000001
transfer A B 999999999999999999999999999999
deposit A +1
transfer A B -1
deposit A 1.5
transfer A B 1,5
deposit A 1e3
transfer A B 1E3
deposit A ١
transfer A B １
deposit A 1a
transfer A B 1_000
deposit A 0x10
transfer A B 1/2
balance A
balance B
history
exit
```

Ожидаемый stdout:

```text
OK DEPOSIT A 25
OK DEPOSIT B 10
OK DEPOSIT A 1
OK TRANSFER B A 1
BALANCE A 27
BALANCE B 9
DEPOSIT A 25
DEPOSIT B 10
DEPOSIT A 1
TRANSFER B A 1
ERR_AMOUNT
ERR_AMOUNT
ERR_AMOUNT
ERR_AMOUNT
ERR_AMOUNT
ERR_AMOUNT
ERR_AMOUNT
ERR_AMOUNT
ERR_AMOUNT
ERR_AMOUNT
ERR_AMOUNT
ERR_AMOUNT
ERR_AMOUNT
ERR_AMOUNT
ERR_AMOUNT
ERR_AMOUNT
BALANCE A 27
BALANCE B 9
DEPOSIT A 25
DEPOSIT B 10
DEPOSIT A 1
TRANSFER B A 1
BYE
```


### T13 Приоритет ошибок и перевод себе

- Требования: R03, R04, R05, R06, R07, R08, R09, R10, R11, R12.
- Проверяемое условие: выводится только первая применимая ошибка в порядке R11. После каждого отказа отдельно проверяются оба баланса и история.
- Тип: ошибочный ввод, совмещение нарушений.
- Действие: запуск программы с указанным stdin.
- Ожидаемый код завершения: не нормируется R01–R12; фактический код сохраняется при запуске.
- Ожидаемый stderr: пустой.
- Статус выполнения: не проверено.

Проверяемые сочетания в порядке входных команд:

1. `transfer C C 0 extra`: неверная арность, счета и сумма → `ERR_COMMAND`.
2. `transfer A C 0`: неверный получатель и сумма → `ERR_ACCOUNT`.
3. `transfer C A 0`: неверный отправитель и сумма → `ERR_ACCOUNT`.
4. `transfer A A 0`: неверная сумма и перевод себе → `ERR_AMOUNT`.
5. `transfer A A 700000000`: перевод себе; сумма превышает средства A, а её прибавление к исходному балансу A превысило бы лимит → `ERR_SAME_ACCOUNT`.
6. `transfer A B 700000000`: недостаток средств A и превышение лимита B → `ERR_FUNDS`.
7. `transfer B A 500000000`: средств B достаточно, но новый баланс A составил бы 1100000000 → `ERR_LIMIT`.
8. `deposit B 1000000001`: недопустимая сумма и потенциальное превышение балансового лимита → `ERR_AMOUNT`.

Вход stdin:

```text
deposit A 600000000
deposit B 1000000000
balance A
balance B
history
transfer C C 0 extra
balance A
balance B
history
transfer A C 0
balance A
balance B
history
transfer C A 0
balance A
balance B
history
transfer A A 0
balance A
balance B
history
transfer A A 700000000
balance A
balance B
history
transfer A B 700000000
balance A
balance B
history
transfer B A 500000000
balance A
balance B
history
deposit B 1000000001
balance A
balance B
history
exit
```

Ожидаемый stdout:

```text
OK DEPOSIT A 600000000
OK DEPOSIT B 1000000000
BALANCE A 600000000
BALANCE B 1000000000
DEPOSIT A 600000000
DEPOSIT B 1000000000
ERR_COMMAND
BALANCE A 600000000
BALANCE B 1000000000
DEPOSIT A 600000000
DEPOSIT B 1000000000
ERR_ACCOUNT
BALANCE A 600000000
BALANCE B 1000000000
DEPOSIT A 600000000
DEPOSIT B 1000000000
ERR_ACCOUNT
BALANCE A 600000000
BALANCE B 1000000000
DEPOSIT A 600000000
DEPOSIT B 1000000000
ERR_AMOUNT
BALANCE A 600000000
BALANCE B 1000000000
DEPOSIT A 600000000
DEPOSIT B 1000000000
ERR_SAME_ACCOUNT
BALANCE A 600000000
BALANCE B 1000000000
DEPOSIT A 600000000
DEPOSIT B 1000000000
ERR_FUNDS
BALANCE A 600000000
BALANCE B 1000000000
DEPOSIT A 600000000
DEPOSIT B 1000000000
ERR_LIMIT
BALANCE A 600000000
BALANCE B 1000000000
DEPOSIT A 600000000
DEPOSIT B 1000000000
ERR_AMOUNT
BALANCE A 600000000
BALANCE B 1000000000
DEPOSIT A 600000000
DEPOSIT B 1000000000
BYE
```

