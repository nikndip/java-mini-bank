# T05 запуск 1

Дата 2026-11-22T18:11:08.665280100+03:00

Требования R02, R05, R06, R07, R08, R10, R11, R12.

Исходник evidence\educational-D01\broken\MiniBank.java

SHA256 72de3e421231941a635900a9799b3eddb12c423f98cfd4f6c6a1964c43c7ed7c

Набор evidence\educational-D01\scenarios-T05-v1.md

SHA256 6c10a96f24ced06634c8f5534b73b131a46cc585d5b0f819c06275d292cbde40

Действие — отдельный процесс Java 17. Аргументы команды — command.txt.

Точный вход — stdin.txt. Ожидаемый stdout — expected.txt. Ожидаемый stderr пуст.

Фактические результаты — stdout.txt и stderr.txt.

Фактический код процесса 0 (не нормируется требованиями).

Завершён в пределах 10 секунд — true.

Статус — не пройдено.
