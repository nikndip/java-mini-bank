# T12 запуск 1

Дата 2026-11-22T18:41:04.022584100+03:00

Требования R02, R05, R06, R07, R08, R10, R11, R12.

Исходник evidence\educational-D01\fixed\MiniBank.java

SHA256 a290c5dc407405a146218fb5b06f16ec46bebb53b3a787f4d0ea91fd75ed4a3b

Набор evidence\educational-D01\scenarios-after-v1.md

SHA256 aee1403671b84315cf4b56faff1d4be5603a0a6af7f449c98cc2afaa5cd110ff

Действие — отдельный процесс Java 17. Аргументы команды — command.txt.

Точный вход — stdin.txt. Ожидаемый stdout — expected.txt. Ожидаемый stderr пуст.

Фактические результаты — stdout.txt и stderr.txt.

Фактический код процесса 0 (не нормируется требованиями).

Завершён в пределах 10 секунд — true.

Статус — пройдено.
