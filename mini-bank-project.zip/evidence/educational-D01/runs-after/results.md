# Фактические результаты проверок

Дата 2026-11-22T18:41:03.670861600+03:00

Java 17.0.21.1

Исходник evidence\educational-D01\fixed\MiniBank.java

SHA256 a290c5dc407405a146218fb5b06f16ec46bebb53b3a787f4d0ea91fd75ed4a3b

Набор evidence\educational-D01\scenarios-after-v1.md

SHA256 aee1403671b84315cf4b56faff1d4be5603a0a6af7f449c98cc2afaa5cd110ff

| Сценарий | Запуск | Требования | Статус | Код процесса | Протокол |
|---|---|---|---|---|---|
| T04 | 1 | R02, R05, R06, R07, R08, R10, R11, R12. | пройдено | 0 | evidence/educational-D01/runs-after/T04-1/record.md |
| T05 | 1 | R02, R05, R06, R07, R08, R10, R11, R12. | пройдено | 0 | evidence/educational-D01/runs-after/T05-1/record.md |
| T07 | 1 | R02, R06, R07, R08, R10, R11, R12. | пройдено | 0 | evidence/educational-D01/runs-after/T07-1/record.md |
| T12 | 1 | R02, R05, R06, R07, R08, R10, R11, R12. | пройдено | 0 | evidence/educational-D01/runs-after/T12-1/record.md |
| T13 | 1 | R03, R04, R05, R06, R07, R08, R09, R10, R11, R12. | пройдено | 0 | evidence/educational-D01/runs-after/T13-1/record.md |

Всего запусков 5. Не пройдено 0.

Сравнение учитывает все символы и завершающие переводы строк. CRLF приводится к LF.
