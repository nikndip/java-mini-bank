# Фактические результаты проверок

Дата 2026-11-22T18:41:50.510827200+03:00

Java 17.0.21.1

Исходник evidence\code-final-v1\MiniBank.java

SHA256 a290c5dc407405a146218fb5b06f16ec46bebb53b3a787f4d0ea91fd75ed4a3b

Набор tests\scenarios-v2.md

SHA256 051f84c6b7a293785db9f572db3c635ffbdb47146716ff17df8723cf1ca6367f

| Сценарий | Запуск | Требования | Статус | Код процесса | Протокол |
|---|---|---|---|---|---|
| T01 | 1 | R02, R03, R06, R10, R12. | пройдено | 0 | evidence/runs-final-v1/T01-1/record.md |
| T01 | 2 | R02, R03, R06, R10, R12. | пройдено | 0 | evidence/runs-final-v1/T01-2/record.md |
| T02 | 1 | R02, R06, R07, R08, R10, R12. | пройдено | 0 | evidence/runs-final-v1/T02-1/record.md |
| T02 | 2 | R02, R06, R07, R08, R10, R12. | пройдено | 0 | evidence/runs-final-v1/T02-2/record.md |
| T03 | 1 | R02, R05, R06, R07, R08, R10, R12. | пройдено | 0 | evidence/runs-final-v1/T03-1/record.md |
| T04 | 1 | R02, R05, R06, R07, R08, R10, R11, R12. | пройдено | 0 | evidence/runs-final-v1/T04-1/record.md |
| T05 | 1 | R02, R05, R06, R07, R08, R10, R11, R12. | пройдено | 0 | evidence/runs-final-v1/T05-1/record.md |
| T06 | 1 | R02, R06, R07, R08, R10, R11, R12. | пройдено | 0 | evidence/runs-final-v1/T06-1/record.md |
| T07 | 1 | R02, R06, R07, R08, R10, R11, R12. | пройдено | 0 | evidence/runs-final-v1/T07-1/record.md |
| T08 | 1 | R03, R05, R06, R07, R08, R10, R12. | пройдено | 0 | evidence/runs-final-v1/T08-1/record.md |
| T09 | 1 | R03, R06, R10, R11, R12. | пройдено | 0 | evidence/runs-final-v1/T09-1/record.md |
| T10 | 1 | R02, R03, R06, R10, R11, R12. | пройдено | 0 | evidence/runs-final-v1/T10-1/record.md |
| T10 | 2 | R02, R03, R06, R10, R11, R12. | пройдено | 0 | evidence/runs-final-v1/T10-2/record.md |
| T11 | 1 | R02, R04, R06, R10, R11, R12. | пройдено | 0 | evidence/runs-final-v1/T11-1/record.md |
| T12 | 1 | R02, R05, R06, R07, R08, R10, R11, R12. | пройдено | 0 | evidence/runs-final-v1/T12-1/record.md |
| T13 | 1 | R03, R04, R05, R06, R07, R08, R09, R10, R11, R12. | пройдено | 0 | evidence/runs-final-v1/T13-1/record.md |
| T14 | 1 | R03, R07, R12. | пройдено | 0 | evidence/runs-final-v1/T14-1/record.md |

Всего запусков 17. Не пройдено 0.

Сравнение учитывает все символы и завершающие переводы строк. CRLF приводится к LF.
