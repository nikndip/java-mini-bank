# T02 запуск 1

Дата 2026-11-22T18:41:50.770035400+03:00

Требования R02, R06, R07, R08, R10, R12.

Исходник evidence\code-final-v1\MiniBank.java

SHA256 a290c5dc407405a146218fb5b06f16ec46bebb53b3a787f4d0ea91fd75ed4a3b

Набор tests\scenarios-v2.md

SHA256 051f84c6b7a293785db9f572db3c635ffbdb47146716ff17df8723cf1ca6367f

Действие — отдельный процесс Java 17. Аргументы команды — command.txt.

Точный вход — stdin.txt. Ожидаемый stdout — expected.txt. Ожидаемый stderr пуст.

Фактические результаты — stdout.txt и stderr.txt.

Фактический код процесса 0 (не нормируется требованиями).

Завершён в пределах 10 секунд — true.

Статус — пройдено.
