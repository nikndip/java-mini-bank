# Неуспешная проверка первой инструкции README

Дата 22.11.2026. Реальная ошибка команды, подготовленной ассистентом.
В Windows PowerShell аргумент -Dfile.encoding=UTF-8 без кавычек был
передан Java некорректно. Java сообщила:
Error: Could not find or load main class .encoding=UTF-8
Caused by: java.lang.ClassNotFoundException: /encoding=UTF-8

Фактические выводы - stdout.txt и stderr.txt, команда - command.json,
исходная инструкция - README-before.txt, точные команды - commands.ps1.
Статус: не пройдено. Java завершилась с кодом 1; MiniBank не был запущен.
Код программы и результаты принятого итогового набора не изменялись.
Локальное исправление инструкции выполняет ассистент без запроса модели.
Успешная повторная проверка сохранена отдельно в package-smoke-v2/.
