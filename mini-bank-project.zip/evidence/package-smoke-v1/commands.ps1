﻿param([string]$ProjectRoot, [string]$JdkRoot)
$env:JAVA_HOME = $JdkRoot
$env:Path = "$JdkRoot\bin;$env:Path"
Set-Location -LiteralPath $ProjectRoot
javac --release 17 -encoding UTF-8 -d out src/MiniBank.java
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Get-Content tests/demo-input.txt | java -Dfile.encoding=UTF-8 -cp out MiniBank
exit $LASTEXITCODE
