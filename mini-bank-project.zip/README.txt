МИНИ-БАНК. Учебный проект по промпт-инжинирингу
Версия программы: final-v1. Дата работы: 22.11.2026.

НАЗНАЧЕНИЕ
Два вымышленных счёта A и B: пополнение, перевод, баланс и общая история.
Все суммы - целые копейки. При каждом запуске балансы равны нулю,
история пуста. Данные сохраняются только в памяти процесса.

ТРЕБОВАНИЯ И СБОРКА
Нужен JDK 17. Внешних зависимостей и установки пакетов нет.
Откройте терминал в корне распакованного проекта. Убедитесь, что команды
java -version и javac -version показывают версию 17.

Сборка:
javac --release 17 -encoding UTF-8 -d out src/MiniBank.java

Интерактивный запуск:
java "-Dfile.encoding=UTF-8" -cp out MiniBank

Вводите по одной команде. Программа не печатает меню и приглашений.
Завершение: exit (ответ BYE) или конец входного потока (без сообщения).

КОМАНДЫ
balance A
deposit A 1000
transfer A B 250
history
exit

Допустимы только A и B, суммы от 1 до 1000000000 включительно,
ASCII-цифры 0-9, начальные нули разрешены. Лимит баланса - 1000000000.
Названия команд чувствительны к регистру, разделители - пробелы и TAB.
При ошибке состояние сохраняется; чтение продолжается.
Полные сообщения, их приоритет и точные правила - docs/requirements-v1.md.

БЫСТРАЯ ПРОВЕРКА В POWERSHELL
После сборки выполните:
Get-Content tests/demo-input.txt | java "-Dfile.encoding=UTF-8" -cp out MiniBank

Ожидаемый ответ - tests/demo-expected.txt. Этот пример не заменяет
принятый итоговый набор. Подтверждение запуска из чистой копии -
evidence/package-smoke-v2/record.md.

ПРОВЕРОЧНЫЙ НАБОР
План: tests/scenarios-v2.md. Финальная сводка: tests/results-final-v1.md.
14 различных сценариев, 17 запусков, пять граничных сценариев.
Полные stdin/expected/stdout/stderr и команды - evidence/runs-final-v1/.
V01-V05 - evidence/source-review-final-v1.md.
Проверочный код tests/MiniBankChecks.java хранится отдельно от программы.
Для самостоятельного повторения в новый каталог результатов:
javac --release 17 -encoding UTF-8 -d check-out tests/MiniBankChecks.java
java -cp check-out MiniBankChecks out new-results tests/scenarios-v2.md src/MiniBank.java
Каталог new-results должен отсутствовать до запуска.

ИСТОРИЯ УЧЕБНОГО СБОЯ
docs/defect-D01-v4.md содержит симптом, область влияния и восстановление.
Намеренный сбой создан в отдельной копии после успешной первичной проверки.
evidence/educational-D01/broken/ и runs-before/ сохраняют неуспех;
fixed/ и runs-after/ - исправление и повторные проверки.
Решение автора о закрытии - docs/ct3-decision-v2.md.

МАТЕРИАЛЫ ПРОЦЕССА
docs/requirements-v1.md - R01-R12 и границы программы.
docs/completion-criteria-v1.md - критерии до первого рабочего запроса;
docs/completion-criteria-v2.md - действующая версия после аудита.
docs/process-map-v2.md - шесть шагов A-F и контрольные точки.
docs/audit-decisions-v1.md - решения по аудиту в отдельном сеансе.
docs/work-log.md - фактические запросы, проверки и решения.
prompts/register.md - отправленные и неотправленные версии промптов.
prompts/ - полные точные запросы, входы, ответы и подготовленные контракты.
evidence/ - снимки версий, метаданные, сборки и протоколы запусков.
docs/traceability-v2.md - итоговая матрица требований (после шага F).
docs/acceptance-v1.md - утверждённый акт; решение автора - docs/ct4-decision-v1.md.
Финальный отчёт PDF предоставляется отдельно от ZIP.

ПРОВЕРЕННЫЙ ИСХОДНИК
src/MiniBank.java: 110 физических строк, 106 без пустых строк и комментариев.
Проверочный код и снимки в evidence/ в объём программы не включены.
SHA256:
a290c5dc407405a146218fb5b06f16ec46bebb53b3a787f4d0ea91fd75ed4a3b
Снимок финальной версии: evidence/code-final-v1/MiniBank.java.
Метаданные: evidence/verification-final-v1.json.

ОКОНЧАТЕЛЬНЫЙ КОМПЛЕКТ
КТ4: Принято, автор nikndip, 22.11.2026.
Для сдачи: mini-bank-report.pdf и mini-bank-project.zip.
Финальная проверка комплекта: evidence/submission-qa-v2.json.
Manifest окончательного ZIP: evidence/file-manifest-v2.json.
Контроль всех 32 критериев: docs/rubric-50-v2.md.
Исторические проекты акта и неуспешные проверки сохранены отдельно.
