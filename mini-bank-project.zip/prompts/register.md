# Реестр промптов проекта «Мини-банк»

Дата 22.11.2026

| Шаг | Файл промпта | Версия | Статус | Запрос и ответ |
|---|---|---|---|---|
| A | prompts/A-audit-v1.md | 1 | Отправлен | Q01. Полный запрос с входами — prompts/A-request-v1.md. Ответ — prompts/A-response-v1.md. |
| B | prompts/B-scenarios-v1.md | 1 | Отправлен | Q02. Полный запрос с входами — prompts/B-request-v1.md. Ответ — prompts/B-response-v1.md. Исходный план — tests/scenarios-v1.md; после сверки подготовлен tests/scenarios-v2.md. |
| B | prompts/B-scenarios-v2.md | 2 | Подготовлен, не отправлен | Для возможного возврата к B. Уточнено обращение с числовым кодом завершения, который не нормируется R01–R12. |
| C | prompts/C-implementation-v1.md | 1 | Отправлен | Q03. Полный запрос с входами — prompts/C-request-v1.md. Ответ — prompts/C-response-v1.md. Исходник сохранён в src/MiniBank.java, копия — evidence/code-v1/MiniBank.java. |
| D | prompts/D-analysis-v1.md | 1 | Отправлен | Q04. Полный запрос — prompts/D-request-v1.md; точное поручение — prompts/D-dispatch-v1.md. Ответ — prompts/D-response-v1.md; уточнение Q04a — prompts/D-followup-v1.md. |
| E — условный | prompts/E-fix-D01-v1.md | 1 | Подготовлен, не отправлен | Сохранён исходный подготовленный промпт; для отправки после решения автора создана версия 2. |
| E — условный | prompts/E-fix-D01-v2.md | 2 | Отправлен | Q05, первая попытка D01. Полный запрос — prompts/E-request-v1.md, поручение — E-dispatch-v1.md, ответ — E-response-v1.md. Исправление применено к отдельной копии; повторные проверки сохранены. |
| D — повторный | prompts/D-analysis-v2.md | 2 | Отправлен | Q06. Полный запрос — D-request-v2.md, поручение — D-dispatch-v2.md, ответ — D-response-v2.md. Рекомендовано закрытие D01 и переход к F после решения автора. |
| F | prompts/F-assessment-v1.md | 1 | Подготовлен, не отправлен | Исходный подготовленный контракт сохранён. После решения КТ3 создана версия 2 для отправки. |
| F | prompts/F-assessment-v2.md | 2 | Отправлен | Q07. Полный запрос — F-request-v1.md; поручение — F-dispatch-v1.md; ответ — F-response-v1.md. Матрица и проект акта извлечены в docs/. |

После сохранения нового промпта его статус меняется на
«подготовлен, не отправлен». При фактической отправке указываются
номер записи журнала и файл полного ответа либо ожидание ответа.
Подготовленные условные промпты не учитываются как выполненные запросы.

| F — проверка комплекта | prompts/F-review-v1.md | 1 | Отправлен | Q08. Полный запрос — F-review-request-v1.md; поручение — F-review-dispatch-v1.md; ответ — F-review-response-v1.md. Уточнение Q08a — F-review-followup-v1.md; решения — docs/submission-review-decisions-v1.md. |
