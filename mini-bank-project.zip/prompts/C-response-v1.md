## 1. src/MiniBank.java

```java
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MiniBank {
    private static final long LIMIT = 1_000_000_000L;

    private static int accountIndex(String account) {
        return switch (account) {
            case "A" -> 0;
            case "B" -> 1;
            default -> -1;
        };
    }

    private static long parseAmount(String text) {
        long amount = 0;
        for (int i = 0; i < text.length(); i++) {
            char digit = text.charAt(i);
            if (digit < '0' || digit > '9') {
                return -1;
            }
            amount = amount * 10 + (digit - '0');
            if (amount > LIMIT) {
                return -1;
            }
        }
        return amount > 0 ? amount : -1;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader input = new BufferedReader(
                new InputStreamReader(System.in, StandardCharsets.UTF_8));
        PrintWriter output = new PrintWriter(System.out, true, StandardCharsets.UTF_8);
        long[] balances = new long[2];
        List<String> history = new ArrayList<>();
        String line;
        while ((line = input.readLine()) != null) {
            String trimmed = line.replaceAll("^[ \\t]+|[ \\t]+$", "");
            String[] parts = trimmed.split("[ \\t]+");
            String command = parts[0];
            int expected = switch (command) {
                case "balance" -> 2;
                case "deposit" -> 3;
                case "transfer" -> 4;
                case "history", "exit" -> 1;
                default -> -1;
            };
            if (parts.length != expected) {
                output.println("ERR_COMMAND");
                continue;
            }
            if (command.equals("exit")) {
                output.println("BYE");
                return;
            }
            if (command.equals("history")) {
                if (history.isEmpty()) {
                    output.println("EMPTY");
                } else {
                    for (String entry : history) {
                        output.println(entry);
                    }
                }
                continue;
            }
            boolean transfer = command.equals("transfer");
            int from = accountIndex(parts[1]);
            int to = transfer ? accountIndex(parts[2]) : from;
            if (from < 0 || to < 0) {
                output.println("ERR_ACCOUNT");
                continue;
            }
            if (command.equals("balance")) {
                output.println("BALANCE " + parts[1] + " " + balances[from]);
                continue;
            }
            long amount = parseAmount(parts[parts.length - 1]);
            if (amount < 0) {
                output.println("ERR_AMOUNT");
                continue;
            }
            if (transfer && from == to) {
                output.println("ERR_SAME_ACCOUNT");
                continue;
            }
            if (transfer && balances[from] < amount) {
                output.println("ERR_FUNDS");
                continue;
            }
            if (balances[to] > LIMIT - amount) {
                output.println("ERR_LIMIT");
                continue;
            }
            if (transfer) {
                balances[from] -= amount;
            }
            balances[to] += amount;
            String entry = transfer
                    ? "TRANSFER " + parts[1] + " " + parts[2] + " " + amount
                    : "DEPOSIT " + parts[1] + " " + amount;
            history.add(entry);
            output.println("OK " + entry);
        }
    }
}
```

## 2. Команды сборки и запуска

Сохранить исходник в UTF-8 как `src/MiniBank.java`. Из корня проекта выполнить в PowerShell:

```powershell
Get-Command javac, java | Select-Object Name, Source
javac -version
java -version
javac --release 17 -encoding UTF-8 src/MiniBank.java
java "-Dfile.encoding=UTF-8" -cp src MiniBank
```

Обе версии инструментов должны относиться к Java 17. Команда сборки соответствует V02; кавычки вокруг параметра запуска сохраняют его передачу одним аргументом в PowerShell.

Каждый из 17 запусков T01–T14 выполняется новым процессом последней командой. В stdin передаётся соответствующий блок в UTF-8 с сохранением табуляций, пустых строк и завершающих переводов строк; затем поток закрывается. Для каждого запуска сохраняются stdout, stderr и фактический код завершения без введения нового числового ожидания.

## 3. Краткая сверка реализации с R01–R12 и ограничения проверки

Проведены просмотр исходника и ручная сверка логики с входами и ожидаемыми ответами T01–T14.

| Требование | Реализация и сверка по тексту |
|---|---|
| R01 | Один исходник без `package`, только стандартная библиотека. Подсчитано **106 учитываемых строк**, всего 110 физических строк. Проверочного кода нет. |
| R02 | Два элемента `long[]`, изначально нулевые; пустая история создаётся при каждом запуске. Изменения сохраняют диапазон балансов. |
| R03 | Построчное чтение, точные имена пяти команд, проверка арности, разделители — пробелы и TAB. Пустые строки дают `ERR_COMMAND`; чтение продолжается. Сверены T08–T10. |
| R04 | Принимаются только точные `A` и `B`; проверяются обе позиции перевода. Сверены T11 и T13. |
| R05 | Посимвольный разбор ASCII-цифр и диапазон 1–1000000000. Начальные нули допустимы; вывод нормализован. Сверен T12. |
| R06 | `balance` выводит идентификатор и текущий баланс в требуемом формате. |
| R07 | Пополнение выполняется после проверки лимита; сообщение содержит нормализованную сумму. Сверены в том числе T04 и T05. |
| R08 | Проверяются средства отправителя, затем лимит получателя; обе стороны изменяются на одинаковую сумму. Сверены T03–T07 и T13. |
| R09 | Перевод себе отклоняется после проверки суммы и до проверки средств. Сверен T13. |
| R10 | В список последовательно добавляются только успешные операции. Просмотр не изменяет историю; пустая история даёт `EMPTY`. |
| R11 | Проверки расположены в заданном порядке. Все предусмотренные условия отказа проверяются до изменения балансов и истории. Сверены T04–T07 и T09–T13. |
| R12 | `exit` печатает `BYE` и возвращает управление из `main`; EOF завершает чтение без сообщения. Вывод выполняется через `println`. Сверены T01 и T14. |

При разборе суммы накопленное значение перед очередным умножением не превышает лимит. Поэтому переполнение `long` исключено: слишком большое значение сразу отклоняется, а длинный префикс нулей обрабатывается без ограничения длиной числового типа.

**Фактическая компиляция и запуски не выполнялись; результаты сценариев ещё не получены.** Соответствие среды Java 17 и поведение программы должны быть подтверждены следующими проверками V01–V05 и T01–T14. Файл в рабочую папку не записан: текущий доступ к файловой системе разрешает только чтение; полное содержимое для сохранения приведено выше.